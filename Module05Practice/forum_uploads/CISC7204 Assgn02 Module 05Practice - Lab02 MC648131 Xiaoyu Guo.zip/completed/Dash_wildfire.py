"""Module 05 Practice Project Lab 02 — Xiaoyu Guo, MC648131."""
from pathlib import Path
import calendar
import pandas as pd
import plotly.express as px
from dash import Dash, dcc, html, Input, Output

df = pd.read_csv(Path(__file__).resolve().parent.parent / "data" / "Historical_Wildfires.csv")
df["Date"] = pd.to_datetime(df["Date"])
df["Year"] = df["Date"].dt.year
df["Month"] = df["Date"].dt.month
regions = {"NSW": "New South Wales", "NT": "Northern Territory", "QL": "Queensland",
           "SA": "South Australia", "TA": "Tasmania", "VI": "Victoria", "WA": "Western Australia"}
app = Dash(__name__)
app.title = "Australia Wildfire Dashboard"

# TASK 2.1: Add the title to the dashboard.
app.layout = html.Main([
    html.H1("Australia Wildfire Dashboard", style={"textAlign": "center", "color": "#503D36", "fontSize": 26}),
    html.P("Xiaoyu Guo · MC648131 | Module 05 Practice Project, Lab 02", style={"textAlign": "center"}),
    html.Div([
        # TASK 2.2: Region radio items and the year dropdown.
        html.Div([
            html.H2("Select Region:", style={"fontSize": 20}),
            dcc.RadioItems(id="region", options=[{"label": name, "value": code} for code, name in regions.items()],
                           value="NSW", inline=True, inputStyle={"marginLeft": "14px", "marginRight": "5px"}),
            html.H2("Select Year:", style={"fontSize": 20}),
            dcc.Dropdown(id="year", options=sorted(df["Year"].unique()), value=2005, clearable=False),
        ], style={"background": "#f6f2eb", "padding": "18px", "borderRadius": "8px"}),
        # TASK 2.3: Two separate divisions for the output charts.
        html.Div([html.Div(id="plot1", style={"width": "50%"}),
                  html.Div(id="plot2", style={"width": "50%"})], style={"display": "flex"}),
    ]),
    html.P("Monthly averages of daily observations. Count refers to detected fire pixels, not separate fires. The dataset ends in 2020; incomplete months are not filled with zeros.", style={"color": "#555"}),
], id="capture", style={"width": "1440px", "boxSizing": "border-box", "margin": "0 auto", "fontFamily": "Arial, sans-serif", "fontSize": 20, "padding": "32px"})

# TASK 2.4: Declare the two output containers and two input values.
@app.callback([Output("plot1", "children"), Output("plot2", "children")],
              [Input("region", "value"), Input("year", "value")])
def reg_year_display(input_region, input_year):
    # TASK 2.5: Filter the data, calculate monthly means and return both charts.
    selected = df[(df["Region"] == input_region) & (df["Year"] == input_year)]
    monthly = selected.groupby("Month", as_index=False)[["Estimated_fire_area", "Count"]].mean()
    monthly["Month_name"] = monthly["Month"].map(lambda month: calendar.month_abbr[month])
    fig1 = px.pie(monthly, values="Estimated_fire_area", names="Month_name",
                  title=f"{input_region}: Monthly Average Estimated Fire Area in {input_year}")
    fig1.update_traces(hovertemplate="%{label}<br>Average area: %{value:.2f} km²<br>Share: %{percent}<extra></extra>")
    fig2 = px.bar(monthly, x="Month_name", y="Count",
                  labels={"Month_name": "Month", "Count": "Average count of detected fire pixels"},
                  title=f"{input_region}: Monthly Average Fire Pixel Count in {input_year}")
    for fig in [fig1, fig2]:
        fig.update_layout(template="plotly_white", height=480, font={"size": 14},
                          title={"font": {"size": 18}}, legend={"font": {"size": 14}},
                          margin={"t": 80, "b": 80})
        fig.update_xaxes(tickfont={"size": 14}, title_font={"size": 14})
        fig.update_yaxes(tickfont={"size": 14}, title_font={"size": 14})
    return dcc.Graph(figure=fig1), dcc.Graph(figure=fig2)

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8065, debug=False)
