# CISC7204 Assignment 02 — Module 04, Lab 02
Xiaoyu Guo · MC648131

## Run
Install with `python -m pip install -r requirements.txt`, then run `python dash_basics.py`.
Open http://127.0.0.1:8042. Press **Ctrl+C** in the same terminal to stop the app.

The app samples 500 rows with `random_state=42`, shows a flight-count pie chart by 250-mile distance group, and includes the H1 title, P description and Graph components. The practice change is included: **Airline On-time Performance Dashboard**, 50px.

Data are read from `airline_data.csv` beside the script. The file is the provided 27,000-row teaching dataset, not the entire US airline database.

Display: the page uses a 1440px outer frame (`#capture`), readable 22px body text, 18px chart labels and 24px chart titles. Charts are 520px high. Numeric results and year callbacks are unchanged.
