"""Module 05 Final Project Lab 02 — Xiaoyu Guo, MC648131."""
from pathlib import Path
import calendar
import pandas as pd
import plotly.express as px
from dash import Dash, dcc, html, Input, Output

data = pd.read_csv(Path(__file__).resolve().parent.parent / "data" / "automobile-sales.csv", parse_dates=["Date"])
data["Month_number"] = data["Date"].dt.month
year_list = list(range(1980, 2024))
app = Dash(__name__)
app.title = "Automobile Sales Statistics Dashboard"

# TASK 2.1: Create the Dash application title.
app.layout = html.Main([
    html.H1("Automobile Sales Statistics Dashboard", style={"textAlign": "center", "color": "#503D36", "fontSize": 24}),
    html.P("Xiaoyu Guo · MC648131 | Module 05 Final Project, Lab 02 | Synthetic assignment data", style={"textAlign": "center"}),
    # TASK 2.2: Report and year selectors, each in a separate division.
    html.Div([
        html.Div([html.Label("Select Statistics:"),
                  dcc.Dropdown(id="dropdown-statistics", options=[
                      {"label": "Yearly Statistics", "value": "Yearly Statistics"},
                      {"label": "Recession Period Statistics", "value": "Recession Period Statistics"}],
                      placeholder="Select a report type", value="Select Statistics", clearable=False)], style={"width": "65%"}),
        html.Div([html.Label("Select Year:"),
                  dcc.Dropdown(id="select-year", options=[{"label": y, "value": y} for y in year_list],
                               placeholder="Select-year", value="Select-year", disabled=True, clearable=False)], style={"width": "30%"}),
    ], style={"display": "flex", "gap": "4%", "background": "#f6f2eb", "padding": "16px", "borderRadius": "8px"}),
    # TASK 2.3: Output container with the required identifier and class.
    html.Div(id="output-container", className="chart-grid", style={"display": "flex", "flexDirection": "column"}),
    html.P("Yearly reports use the selected year except the whole-period annual trend. Recession reports pool all records with Recession = 1. These charts describe synthetic observations and do not establish causal effects.", style={"fontSize": 18, "color": "#555"}),
], id="capture", style={"width": "1440px", "boxSizing": "border-box", "margin": "0 auto", "fontFamily": "Arial, sans-serif", "fontSize": 20, "padding": "32px"})

# TASK 2.4: Enable the year selector only for a yearly report.
@app.callback(Output("select-year", "disabled"), Input("dropdown-statistics", "value"))
def update_input_container(selected_statistics):
    return selected_statistics != "Yearly Statistics"

@app.callback(Output("output-container", "children"),
              [Input("dropdown-statistics", "value"), Input("select-year", "value")])
def update_output_container(selected_statistics, input_year):
    # TASK 2.5: Four graphs for all recession observations.
    if selected_statistics == "Recession Period Statistics":
        recession_data = data[data["Recession"] == 1]
        yearly_rec = recession_data.groupby("Year", as_index=False)["Automobile_Sales"].mean()
        average_sales = recession_data.groupby("Vehicle_Type", as_index=False)["Automobile_Sales"].mean()
        exp_rec = recession_data.groupby("Vehicle_Type", as_index=False)["Advertising_Expenditure"].sum()
        unemp_data = recession_data.groupby(["unemployment_rate", "Vehicle_Type"], as_index=False)["Automobile_Sales"].mean()
        fig1 = px.line(yearly_rec, x="Year", y="Automobile_Sales", markers=True, title="Average Automobile Sales during Recession Years")
        fig2 = px.bar(average_sales, x="Vehicle_Type", y="Automobile_Sales", title="Average Sales by Vehicle Type during Recessions")
        fig3 = px.pie(exp_rec, values="Advertising_Expenditure", names="Vehicle_Type", title="Advertising Expenditure Share during Recessions")
        fig4 = px.bar(unemp_data, x="unemployment_rate", y="Automobile_Sales", color="Vehicle_Type", barmode="group",
                      labels={"unemployment_rate": "Unemployment rate (%)", "Automobile_Sales": "Average automobile sales"},
                      title="Unemployment Rate, Vehicle Type and Sales")
    # TASK 2.6: Four graphs for the yearly report.
    elif selected_statistics == "Yearly Statistics" and input_year in year_list:
        yearly_data = data[data["Year"] == input_year]
        yas = data.groupby("Year", as_index=False)["Automobile_Sales"].mean()
        mas = yearly_data.groupby("Month_number", as_index=False)["Automobile_Sales"].sum()
        mas["Month"] = mas["Month_number"].map(lambda month: calendar.month_abbr[month])
        avr_vdata = yearly_data.groupby("Vehicle_Type", as_index=False)["Automobile_Sales"].mean()
        exp_data = yearly_data.groupby("Vehicle_Type", as_index=False)["Advertising_Expenditure"].sum()
        fig1 = px.line(yas, x="Year", y="Automobile_Sales", title="Average Yearly Automobile Sales — Whole Period")
        fig2 = px.line(mas, x="Month", y="Automobile_Sales", markers=True, title=f"Total Monthly Automobile Sales in {input_year}")
        fig3 = px.bar(avr_vdata, x="Vehicle_Type", y="Automobile_Sales", title=f"Average Sales by Vehicle Type in {input_year}")
        fig4 = px.pie(exp_data, values="Advertising_Expenditure", names="Vehicle_Type", title=f"Advertising Expenditure by Vehicle Type in {input_year}")
    else:
        return html.P("Select a report type and, for yearly statistics, a year.", style={"padding": "24px"})
    for fig in [fig1, fig2, fig3, fig4]:
        fig.update_layout(template="plotly_white", height=460, font={"size": 14},
                          title={"font": {"size": 18}},
                          margin={"t": 80, "b": 100}, legend={"font": {"size": 14}})
        fig.update_xaxes(title_text=fig.layout.xaxis.title.text or "Year",
                         tickfont={"size": 14}, title_font={"size": 14})
        fig.update_yaxes(tickfont={"size": 14}, title_font={"size": 14})
    # Two flex rows, each containing two charts, form the required 2 x 2 grid.
    return [html.Div([dcc.Graph(figure=fig1, style={"width": "50%"}), dcc.Graph(figure=fig2, style={"width": "50%"})], className="chart-item", style={"display": "flex"}),
            html.Div([dcc.Graph(figure=fig3, style={"width": "50%"}), dcc.Graph(figure=fig4, style={"width": "50%"})], className="chart-item", style={"display": "flex"})]

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8066, debug=False)
