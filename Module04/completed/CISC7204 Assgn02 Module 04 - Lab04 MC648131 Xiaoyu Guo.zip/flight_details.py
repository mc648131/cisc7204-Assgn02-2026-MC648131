"""Module 04, Lab 04 including practice tasks — Xiaoyu Guo, MC648131."""
from pathlib import Path

import pandas as pd
import plotly.express as px
from dash import Dash, Input, Output, dcc, html
from dash.exceptions import PreventUpdate

# Task 1: read the supplied dataset locally.
airline_data = pd.read_csv(
    Path(__file__).parent / "airline_data.csv",
    encoding="ISO-8859-1",
    dtype={"Div1Airport": str, "Div1TailNum": str,
           "Div2Airport": str, "Div2TailNum": str},
)

# Tasks 2–3: arrange the five graphs in three segments.
app = Dash(__name__)
app.layout = html.Div([
    html.H1("Flight Details Statistics Dashboard",
            style={"textAlign": "center", "color": "#503D36", "fontSize": 35}),
    html.P("Xiaoyu Guo | MC648131 | Module 04 — Lab 04"),
    html.Div([
        "Input Year: ",
        dcc.Input(id="input-year", value=2010, type="number",
                  min=2010, max=2020, step=1, debounce=True,
                  style={"height": "35px", "fontSize": 30}),
    ], style={"fontSize": 30}),
    html.Br(), html.Br(),
    html.Div([
        html.Div(dcc.Graph(id="carrier-plot"), style={"width": "50%"}),
        html.Div(dcc.Graph(id="weather-plot"), style={"width": "50%"}),
    ], style={"display": "flex"}),
    html.Div([
        html.Div(dcc.Graph(id="nas-plot"), style={"width": "50%"}),
        html.Div(dcc.Graph(id="security-plot"), style={"width": "50%"}),
    ], style={"display": "flex"}),
    html.Div(dcc.Graph(id="late-plot"), style={"width": "65%"}),
], id="capture", style={"fontFamily": "Arial, sans-serif", "fontSize": 22,
                        "width": "1440px", "maxWidth": "100%", "margin": "0 auto",
                        "boxSizing": "border-box", "padding": "24px",
                        "backgroundColor": "white"})


# Task 4: compute each mean using its non-missing observations.
def compute_info(airline_data, entered_year):
    df = airline_data[airline_data["Year"] == int(entered_year)]
    groups = ["Month", "Reporting_Airline"]
    avg_car = df.groupby(groups)["CarrierDelay"].mean().reset_index()
    avg_weather = df.groupby(groups)["WeatherDelay"].mean().reset_index()
    avg_nas = df.groupby(groups)["NASDelay"].mean().reset_index()
    avg_sec = df.groupby(groups)["SecurityDelay"].mean().reset_index()
    avg_late = df.groupby(groups)["LateAircraftDelay"].mean().reset_index()
    return avg_car, avg_weather, avg_nas, avg_sec, avg_late


# Tasks 5–6: one input updates all five output figures.
@app.callback(
    [Output("carrier-plot", "figure"), Output("weather-plot", "figure"),
     Output("nas-plot", "figure"), Output("security-plot", "figure"),
     Output("late-plot", "figure")],
    Input("input-year", "value"),
)
def get_graph(entered_year):
    if entered_year is None or entered_year not in range(2010, 2021):
        raise PreventUpdate
    avg_car, avg_weather, avg_nas, avg_sec, avg_late = compute_info(airline_data, entered_year)
    carrier_fig = px.line(avg_car, x="Month", y="CarrierDelay", color="Reporting_Airline",
                          title="Average carrier delay time<br>(minutes) by airline")
    weather_fig = px.line(avg_weather, x="Month", y="WeatherDelay", color="Reporting_Airline",
                          title="Average weather delay time<br>(minutes) by airline")
    nas_fig = px.line(avg_nas, x="Month", y="NASDelay", color="Reporting_Airline",
                      title="Average NAS delay time<br>(minutes) by airline")
    sec_fig = px.line(avg_sec, x="Month", y="SecurityDelay", color="Reporting_Airline",
                      title="Average security delay time<br>(minutes) by airline")
    late_fig = px.line(avg_late, x="Month", y="LateAircraftDelay", color="Reporting_Airline",
                       title="Average late aircraft delay time<br>(minutes) by airline")
    figures = [carrier_fig, weather_fig, nas_fig, sec_fig, late_fig]
    for fig in figures:
        fig.update_layout(template="plotly_white", height=520,
                          font_size=18, title_font_size=24,
                          margin={"l": 75, "r": 20, "t": 110, "b": 190},
                          legend={"orientation": "h", "x": 0, "y": -0.5,
                                  "xanchor": "left", "yanchor": "top",
                                  "entrywidth": 62, "title": {"text": ""}})
        fig.update_xaxes(dtick=1)
    return figures


# Practice tasks: the revised title is 35px and the file is flight_details.py.
# Run the app, then press Ctrl+C in the same terminal to stop it.
if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8045, debug=False)
