# CISC7204 Assignment 02 — Module 05 Final, Lab 02

Xiaoyu Guo · MC648131

## Run

Use Python 3.12. Extract the project and run these commands from its root folder:

```text
python -m pip install -r completed/requirements.txt
python completed/DV0101EN-Final-Assign-Part-2-Questions.py
```

Open http://127.0.0.1:8066/ . Press Ctrl+C in the terminal to stop the application.
Keep the completed/ and data/ folders beside each other; the program reads the bundled CSV.

The supplied automobile data are synthetic. The app uses 1980–2023, as specified by the detailed dropdown task and supplied skeleton. Year selection is enabled for Yearly Statistics; Recession Period Statistics pools recession records.

The screenshots/ folder contains the completed task code and both required dashboard views.
