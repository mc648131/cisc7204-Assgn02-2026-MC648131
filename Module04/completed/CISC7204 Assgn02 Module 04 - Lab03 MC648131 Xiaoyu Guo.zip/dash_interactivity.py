"""Module 04, Lab 03 — Xiaoyu Guo, MC648131."""
from pathlib import Path

import pandas as pd
import plotly.graph_objects as go
from dash import Dash, Input, Output, dcc, html
from dash.exceptions import PreventUpdate

# Task 1: read the provided airline data from the local project folder.
airline_data = pd.read_csv(
    Path(__file__).parent / "airline_data.csv",
    encoding="ISO-8859-1",
    dtype={"Div1Airport": str, "Div1TailNum": str,
           "Div2Airport": str, "Div2TailNum": str},
)

# Task 2: connect a numeric year input to the line chart.
app = Dash(__name__)
app.layout = html.Div([
    html.H1("Airline Performance Dashboard",
            style={"textAlign": "center", "color": "#503D36", "fontSize": 40}),
    html.P("Xiaoyu Guo | MC648131 | Module 04 — Lab 03"),
    html.Div([
        "Input Year: ",
        dcc.Input(id="input-year", value=2010, type="number",
                  min=2010, max=2020, step=1, debounce=True,
                  style={"height": "50px", "fontSize": 35}),
    ], style={"fontSize": 40}),
    html.Br(), html.Br(),
    html.Div(dcc.Graph(id="line-plot")),
], id="capture", style={"fontFamily": "Arial, sans-serif", "fontSize": 22,
                        "width": "1440px", "maxWidth": "100%", "margin": "0 auto",
                        "boxSizing": "border-box", "padding": "24px",
                        "backgroundColor": "white"})


# Task 3: recompute the monthly average when the input year changes.
@app.callback(Output("line-plot", "figure"), Input("input-year", "value"))
def get_graph(entered_year):
    if entered_year is None or entered_year not in range(2010, 2021):
        raise PreventUpdate
    df = airline_data[airline_data["Year"] == int(entered_year)]
    line_data = df.groupby("Month")["ArrDelay"].mean().reset_index()
    fig = go.Figure(go.Scatter(
        x=line_data["Month"], y=line_data["ArrDelay"],
        mode="lines", marker={"color": "green"}, line={"color": "green"},
    ))
    fig.update_layout(title="Month vs Average Flight Delay Time",
                      xaxis_title="Month", yaxis_title="ArrDelay",
                      template="plotly_white", font_size=18,
                      title_font_size=24, height=520)
    fig.update_xaxes(dtick=1)
    return fig


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8043, debug=False)
