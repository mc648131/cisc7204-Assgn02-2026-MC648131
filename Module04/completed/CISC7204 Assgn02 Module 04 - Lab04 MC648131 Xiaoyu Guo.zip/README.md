# CISC7204 Assignment 02 — Module 04, Lab 04
Xiaoyu Guo · MC648131

## Run
Install with `python -m pip install -r requirements.txt`, then run `python flight_details.py`.
Open http://127.0.0.1:8045. Enter a whole year from 2010 to 2020 and press Enter or leave the input. Press **Ctrl+C** in the same terminal to stop the app.

One callback updates all five monthly averages by reporting airline: carrier, weather, NAS, security and late-aircraft delay. The first two rows contain paired graphs; the last segment contains late-aircraft delay. The practice changes are included: **Flight Details Statistics Dashboard**, 35px, saved as `flight_details.py`.

Means use the non-missing values of each delay column. Missing delay entries are not replaced with zero; the results therefore describe records with a reported value. The local teaching dataset is included as `airline_data.csv`.

Display: the page uses a 1440px outer frame (`#capture`), readable 22px body text, 18px chart labels and 24px chart titles. Charts are 520px high. Numeric results and year callbacks are unchanged.
