"""Module 04, Lab 02 — Xiaoyu Guo, MC648131."""
from pathlib import Path

import pandas as pd
import plotly.express as px
from dash import Dash, dcc, html

# Task 1: read the local data and use the required reproducible sample.
airline_data = pd.read_csv(
    Path(__file__).parent / "airline_data.csv",
    encoding="ISO-8859-1",
    dtype={"Div1Airport": str, "Div1TailNum": str,
           "Div2Airport": str, "Div2TailNum": str},
)
data = airline_data.sample(n=500, random_state=42)
fig = px.pie(data, values="Flights", names="DistanceGroup",
             title="Distance group proportion by flights")
fig.update_layout(font_size=18, title_font_size=24, height=520)

# Tasks 2–5 and the practice exercise: title, paragraph and graph.
app = Dash(__name__)
app.layout = html.Div([
    html.H1("Airline On-time Performance Dashboard",
            style={"textAlign": "center", "color": "#503D36", "fontSize": 50}),
    html.P("Proportion of distance group (250 mile distance interval group) by flights.",
           style={"textAlign": "center", "color": "#F57241"}),
    html.P("Xiaoyu Guo | MC648131 | Module 04 — Lab 02",
           style={"textAlign": "center"}),
    dcc.Graph(id="distance-pie", figure=fig),
], id="capture", style={"fontFamily": "Arial, sans-serif", "fontSize": 22,
                        "width": "1440px", "maxWidth": "100%", "margin": "0 auto",
                        "boxSizing": "border-box", "padding": "24px",
                        "backgroundColor": "white"})

# Task 6: run locally. Press Ctrl+C in this terminal to stop the app.
if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8042, debug=False)
