"""Module 04, Lab 03 practice exercise — Xiaoyu Guo, MC648131."""
from pathlib import Path

import pandas as pd
import plotly.express as px
from dash import Dash, Input, Output, dcc, html
from dash.exceptions import PreventUpdate

# 1. Import libraries and read the local dataset.
airline_data = pd.read_csv(
    Path(__file__).parent / "airline_data.csv",
    encoding="ISO-8859-1",
    dtype={"Div1Airport": str, "Div1TailNum": str,
           "Div2Airport": str, "Div2TailNum": str},
)

# 2. Add the title, numeric year input and bar-chart output.
app = Dash(__name__)
app.layout = html.Div([
    html.H1("Total number of flights to the destination state split by reporting airline",
            style={"textAlign": "center", "color": "#503D36", "fontSize": 40}),
    html.P("Xiaoyu Guo | MC648131 | Module 04 — Lab 03 practice"),
    html.Div([
        "Input Year: ",
        dcc.Input(id="input-year", value=2010, type="number",
                  min=2010, max=2020, step=1, debounce=True,
                  style={"height": "50px", "fontSize": 35}),
    ], style={"fontSize": 40}),
    html.Br(), html.Br(),
    html.Div(dcc.Graph(id="bar-plot"), style={"fontSize": 35}),
], id="capture", style={"fontFamily": "Arial, sans-serif", "fontSize": 22,
                        "width": "1440px", "maxWidth": "100%", "margin": "0 auto",
                        "boxSizing": "border-box", "padding": "24px",
                        "backgroundColor": "white"})


# 3–4. Filter the selected year, then sum flights for each state/airline pair.
@app.callback(Output("bar-plot", "figure"), Input("input-year", "value"))
def get_graph(entered_year):
    if entered_year is None or entered_year not in range(2010, 2021):
        raise PreventUpdate
    df = airline_data[airline_data["Year"] == int(entered_year)]
    bar_data = df.groupby(["DestState", "Reporting_Airline"])["Flights"].sum().reset_index()
    fig = px.bar(bar_data, x="DestState", y="Flights", color="Reporting_Airline",
                 title="Total number of flights to the destination state<br>split by reporting airline",
                 barmode="stack", template="plotly_white")
    fig.update_layout(xaxis_title="DestState", yaxis_title="Flights",
                      height=520, font_size=18, title_font_size=24,
                      margin={"t": 110, "b": 190},
                      legend={"orientation": "h", "x": 0, "y": -0.5,
                              "xanchor": "left", "yanchor": "top",
                              "entrywidth": 62, "title": {"text": ""}})
    return fig


# 5. Run the new dashboard. Press Ctrl+C to stop it.
if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8044, debug=False)
