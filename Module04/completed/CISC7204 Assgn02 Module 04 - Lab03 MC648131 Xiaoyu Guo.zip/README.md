# CISC7204 Assignment 02 — Module 04, Lab 03
Xiaoyu Guo · MC648131

## Run
Install with `python -m pip install -r requirements.txt`.

- Main lab: `python dash_interactivity.py`, then open http://127.0.0.1:8043.
- Practice exercise: `python dash_interactivity_barplot.py`, then open http://127.0.0.1:8044.

Enter a whole year from 2010 to 2020 and press Enter or leave the input. The first callback shows mean ArrDelay by month. The second filters that year, groups by destination state and reporting airline, and sums Flights. Both use a 2010 default. Press **Ctrl+C** in the relevant terminal to stop an app.

Missing arrival delays are excluded from the monthly mean. The bar chart counts rows from the provided sample; it is not a census of all US flights. Code and local `airline_data.csv` are included.

Display: the page uses a 1440px outer frame (`#capture`), readable 22px body text, 18px chart labels and 24px chart titles. Charts are 520px high. Numeric results and year callbacks are unchanged.
