# CISC7204 Assignment 02 — Module 05 Practice, Lab 02

Xiaoyu Guo · MC648131

## Run

Use Python 3.12. Extract the project and run these commands from its root folder:

```text
python -m pip install -r completed/requirements.txt
python completed/Dash_wildfire.py
```

Open http://127.0.0.1:8065/ . Press Ctrl+C in the terminal to stop the application.
Keep the completed/ and data/ folders beside each other; the program reads the bundled CSV.

The wildfire data span 2005–2020. Select a region and year to display the monthly charts.

The screenshots/ folder contains the completed task code and both required dashboard views.
